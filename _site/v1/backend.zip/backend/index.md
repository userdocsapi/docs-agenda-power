---
title: 'Backend'
nav_order: 2
---

# Documentação do Backend

Este documento contém a estrutura e explicação dos módulos backend do sistema.
