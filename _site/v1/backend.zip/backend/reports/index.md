---
title: 'Reports'
parent: 'Backend'
nav_order: 1
---

# Módulo: Reports

Documentação relacionada ao módulo `reports`.
