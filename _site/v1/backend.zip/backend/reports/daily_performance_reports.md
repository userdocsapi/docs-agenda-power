---
title: 'Daily performance reports'
parent: 'Reports'
nav_order: 2
---

# Daily performance reports

Descrição sobre `daily_performance_reports`.
