---
title: 'Total customer stats'
parent: 'Reports'
nav_order: 2
---

# Total customer stats

Descrição sobre `total_customer_stats`.
