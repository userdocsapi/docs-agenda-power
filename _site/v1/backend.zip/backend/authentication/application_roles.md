---
title: 'Application roles'
parent: 'Authentication'
nav_order: 2
---

# Application roles

Descrição sobre `application_roles`.
