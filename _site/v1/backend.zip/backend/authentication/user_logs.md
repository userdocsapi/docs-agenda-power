---
title: 'User logs'
parent: 'Authentication'
nav_order: 2
---

# User logs

Descrição sobre `user_logs`.
