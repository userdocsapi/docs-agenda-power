---
title: 'Authentication'
parent: 'Backend'
nav_order: 1
---

# Módulo: Authentication

Documentação relacionada ao módulo `authentication`.
