---
title: 'Anamnese answers'
parent: 'Anamnese'
nav_order: 2
---

# Anamnese answers

Descrição sobre `anamnese_answers`.



