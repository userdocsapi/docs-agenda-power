---
title: 'Anamnese questions'
parent: 'Anamnese'
nav_order: 2
---

# Anamnese questions

Descrição sobre `anamnese_questions`.
