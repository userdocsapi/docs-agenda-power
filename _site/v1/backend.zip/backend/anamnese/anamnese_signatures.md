---
title: 'Anamnese signatures'
parent: 'Anamnese'
nav_order: 2
---

# Anamnese signatures

Descrição sobre `anamnese_signatures`.
