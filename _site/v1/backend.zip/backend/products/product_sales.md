---
title: 'Product sales'
parent: 'Products'
nav_order: 2
---

# Product sales

Descrição sobre `product_sales`.
