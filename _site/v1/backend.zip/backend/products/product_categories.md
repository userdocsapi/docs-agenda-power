---
title: 'Product categories'
parent: 'Products'
nav_order: 2
---

# Product categories

Descrição sobre `product_categories`.
