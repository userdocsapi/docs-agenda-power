---
title: 'Product sale items'
parent: 'Products'
nav_order: 2
---

# Product sale items

Descrição sobre `product_sale_items`.
