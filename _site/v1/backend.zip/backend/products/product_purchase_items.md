---
title: 'Product purchase items'
parent: 'Products'
nav_order: 2
---

# Product purchase items

Descrição sobre `product_purchase_items`.
