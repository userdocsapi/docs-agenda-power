---
title: 'Expense categories'
parent: 'Finance'
nav_order: 2
---

# Expense categories

Descrição sobre `expense_categories`.
