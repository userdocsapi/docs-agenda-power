---
title: 'Accounts receivables'
parent: 'Finance'
nav_order: 2
---

# Accounts receivables

Descrição sobre `accounts_receivables`.
