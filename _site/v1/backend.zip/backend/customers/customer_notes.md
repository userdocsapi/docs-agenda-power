---
title: 'Customer notes'
parent: 'Customers'
nav_order: 2
---

# Customer notes

Descrição sobre `customer_notes`.
