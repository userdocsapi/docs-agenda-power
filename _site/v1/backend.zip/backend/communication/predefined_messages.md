---
title: 'Predefined messages'
parent: 'Communication'
nav_order: 2
---

# Predefined messages

Descrição sobre `predefined_messages`.
