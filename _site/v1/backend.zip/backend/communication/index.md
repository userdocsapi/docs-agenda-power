---
title: 'Communication'
parent: 'Backend'
nav_order: 1
---

# Módulo: Communication

Documentação relacionada ao módulo `communication`.
