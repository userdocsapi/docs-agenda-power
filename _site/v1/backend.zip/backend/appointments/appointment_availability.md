---
title: 'Appointment availability'
parent: 'Appointments'
nav_order: 2
---

# Appointment availability

Descrição sobre `appointment_availability`.
