---
title: 'Waiting appointments'
parent: 'Appointments'
nav_order: 2
---

# Waiting appointments

Descrição sobre `waiting_appointments`.
