---
title: 'Appointment repeat info'
parent: 'Appointments'
nav_order: 2
---

# Appointment repeat info

Descrição sobre `appointment_repeat_info`.
